# Concepts Used

1) Reading each File from specific folder
2) How to get Files from particular Folder
3) Use of Regular Expression
4) How to attach the HTML Template in Mail Body
5) How to change the parameters/values that are extracted using Regex which should reflect in Mail Body